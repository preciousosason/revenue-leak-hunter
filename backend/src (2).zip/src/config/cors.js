export const CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods":
        "GET, POST, PATCH, DELETE, OPTIONS",
    "Access-Control-Allow-Headers":
        "Content-Type, Authorization",
    "Content-Type": "application/json"
};