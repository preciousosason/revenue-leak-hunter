import { api } from "../core/api.js";
import { escapeHTML } from "../core/utils.js";

let root = null;
let currentTab = "dashboard";
let campaigns = [];
const e = v => escapeHTML(String(v ?? ""));
const fmt = v => v ? new Date(v).toLocaleString() : "—";
const badge = value => `<span class="outreach-badge ${e(value)}">${e(String(value||"unknown").replaceAll("_"," "))}</span>`;

function shell(content) {
    root.innerHTML = `<header class="outreach-head"><div><span class="outreach-kicker">OUTREACH // CONTROL</span><h2>Outreach Center</h2><p>Research, schedule and manage personalized prospecting without mixing it with client notifications.</p></div></header>
    <nav class="outreach-tabs">
      ${[["dashboard","Dashboard"],["intelligence","Intelligence"],["campaigns","Campaigns"],["create","Create Campaign"],["due","Due Today"],["templates","Templates"],["trash","Recycle Bin"]].map(([id,label])=>`<button class="outreach-tab ${currentTab===id?'active':''}" data-outreach-tab="${id}">${label}</button>`).join("")}
    </nav><div id="outreach-workspace">${content}</div>`;
    root.querySelectorAll("[data-outreach-tab]").forEach(b=>b.addEventListener("click",()=>openTab(b.dataset.outreachTab)));
}
function loading(){ shell(`<div class="outreach-state">Loading outreach intelligence…</div>`); }
function errorView(err){ shell(`<div class="outreach-state error">${e(err.message||err)}</div>`); }

async function dashboard(){
    const [data,google]=await Promise.all([api("/api/admin/outreach/dashboard"),api("/api/admin/outreach/google/status")]);
    const c=data.summary?.campaigns||{}, p=data.summary?.prospects||{};
    shell(`<section class="outreach-card google-connection ${google.connected?'connected':'disconnected'}"><div><span class="outreach-kicker">SENDING // GOOGLE WORKSPACE</span><h3>${google.connected?'Google Workspace Connected':'Connect Google Workspace'}</h3><p>${google.connected?`${e(google.sender)} is authorized for manual outreach sending.`:'Connect precious@leakendia.com before sending real outreach emails.'}</p></div><div class="google-actions">${google.connected?`<span class="connection-pill">● CONNECTED</span><button id="google-disconnect" class="text-button">Disconnect</button>`:`<button id="google-connect" class="outreach-primary" ${google.configured?'':'disabled'}>${google.configured?'Connect Google Workspace':'OAuth secrets required'}</button>`}</div></section>
    <div class="outreach-metrics">
      <article><span>ACTIVE CAMPAIGNS</span><strong>${c.active||0}</strong></article><article><span>DUE TODAY</span><strong>${data.summary?.due_today||0}</strong></article><article><span>REPLIED</span><strong>${p.replied||0}</strong></article><article><span>CONVERTED</span><strong>${p.converted||0}</strong></article>
    </div><div class="outreach-grid"><section class="outreach-card"><div class="outreach-card-head"><h3>Recent Activity</h3><button data-jump="due">Open Queue</button></div><div class="outreach-list">${(data.activity||[]).length?(data.activity||[]).map(a=>`<div class="activity-row"><div><strong>${e(a.prospect_name||a.campaign_name||a.type)}</strong><span>${e(a.detail||a.type.replaceAll('_',' '))}</span></div><time>${fmt(a.created_at)}</time></div>`).join(""):`<div class="outreach-empty">No outreach activity yet.</div>`}</div></section>
    <section class="outreach-card"><h3>Operating Rules</h3><div class="rule-list"><p><strong>15/day</strong><span>Default initial-contact queue.</span></p><p><strong>5 max</strong><span>Follow-ups stop after step five.</span></p><p><strong>Human controlled</strong><span>Emails send only when you review and press Send Email.</span></p><p><strong>Suppression</strong><span>Replies, conversion and Do Not Contact stop the sequence.</span></p></div></section></div>`);
    root.querySelector('[data-jump="due"]')?.addEventListener('click',()=>openTab('due'));
    root.querySelector('#google-connect')?.addEventListener('click',async()=>{try{const r=await api('/api/admin/outreach/google/connect',{method:'POST'});window.open(r.authorization_url,'_blank','noopener');}catch(err){alert(err.message);}});
    root.querySelector('#google-disconnect')?.addEventListener('click',async()=>{if(!confirm('Disconnect Google Workspace from Leakendia Outreach?'))return;await api('/api/admin/outreach/google/disconnect',{method:'POST'});dashboard();});
}

async function campaignList(){
    const data=await api("/api/admin/outreach/campaigns"); campaigns=data.campaigns||[];
    shell(`<div class="outreach-toolbar"><div><h3>Campaign Library</h3><p>Active, paused, completed and archived campaigns.</p></div><select id="campaign-filter"><option value="all">All states</option><option>active</option><option>paused</option><option>completed</option><option>archived</option><option>draft</option></select></div><div id="campaign-cards" class="campaign-cards"></div>`);
    const render=()=>{const f=root.querySelector('#campaign-filter').value;const rows=campaigns.filter(c=>f==='all'||c.status===f);root.querySelector('#campaign-cards').innerHTML=rows.length?rows.map(c=>`<button class="campaign-card" data-campaign="${e(c.id)}"><div class="campaign-card-top">${badge(c.status)}<span>${c.prospect_count||0}/${c.max_prospects}</span></div><h3>${e(c.name)}</h3><p>${e(c.description||'No description')}</p><div class="campaign-progress"><i style="width:${Math.min(100,Math.round((Number(c.contacted_count||0)/Math.max(1,Number(c.prospect_count||0)))*100))}%"></i></div><footer><span>${c.contacted_count||0} contacted</span><span>${c.reply_count||0} replies</span><span>${c.converted_count||0} converted</span></footer></button>`).join(''):`<div class="outreach-empty">No campaigns in this state.</div>`;root.querySelectorAll('[data-campaign]').forEach(b=>b.addEventListener('click',()=>campaignDetail(b.dataset.campaign)));};
    root.querySelector('#campaign-filter').addEventListener('change',render);render();
}

async function createCampaign(){
    shell(`<section class="outreach-card form-card"><h3>Create Campaign</h3><p>Scheduling is anchored to one campaign start date, so adding prospects later does not scramble the 15/day plan.</p><form id="campaign-form" class="outreach-form"><label>Name<input name="name" required maxlength="160" placeholder="SaaS Conversion Audit — October"></label><label>Description<textarea name="description" rows="3"></textarea></label><div class="form-row"><label>Start date<input name="start_date" type="date" required value="${new Date().toISOString().slice(0,10)}"></label><label>Daily initial limit<input name="daily_limit" type="number" min="1" max="50" value="15"></label><label>Prospect target/max<input name="max_prospects" type="number" min="1" max="500" value="60"></label></div><fieldset><legend>Follow-up intervals in days</legend><div class="form-row five">${[3,4,5,7,10].map((v,i)=>`<label>#${i+1}<input name="f${i+1}" type="number" min="1" max="30" value="${v}"></label>`).join('')}</div></fieldset><div id="campaign-form-status"></div><button class="outreach-primary" type="submit">Create Campaign</button></form></section>`);
    root.querySelector('#campaign-form').addEventListener('submit',async ev=>{ev.preventDefault();const f=new FormData(ev.currentTarget),status=root.querySelector('#campaign-form-status');try{status.textContent='Creating…';const r=await api('/api/admin/outreach/campaigns',{method:'POST',body:JSON.stringify({name:f.get('name'),description:f.get('description'),start_date:f.get('start_date'),daily_limit:f.get('daily_limit'),max_prospects:f.get('max_prospects'),followup_intervals:[1,2,3,4,5].map(i=>f.get(`f${i}`))})});await campaignDetail(r.campaign_id);}catch(err){status.textContent=err.message;status.className='error-text';}});
}

async function campaignDetail(id){
    const data=await api(`/api/admin/outreach/campaigns/${id}`), c=data.campaign, prospects=data.prospects||[];
    shell(`<div class="detail-top"><button class="text-button" id="back-campaigns">← Campaigns</button><div class="detail-actions"><button class="outreach-danger" id="trash-campaign">Move to Trash</button><select id="campaign-state">${['active','paused','completed','archived','draft'].map(s=>`<option ${s===c.status?'selected':''}>${s}</option>`).join('')}</select><button id="save-campaign-state">Save state</button></div></div><section class="outreach-card"><div class="campaign-title"><div>${badge(c.status)}<h3>${e(c.name)}</h3><p>${e(c.description||'')}</p></div><div class="campaign-facts"><span>Start <strong>${e(c.start_date)}</strong></span><span>Daily <strong>${c.daily_limit}</strong></span><span>Capacity <strong>${prospects.length}/${c.max_prospects}</strong></span></div></div></section>
    <div class="outreach-grid campaign-work"><section class="outreach-card"><h3>Add Prospect</h3><form id="prospect-form" class="outreach-form compact"><div class="form-row"><label>Name<input name="name" required></label><label>Email<input id="prospect-email" name="email" type="email" required></label></div><div id="email-health" class="email-health neutral">Enter an email to check mail infrastructure.</div><div class="form-row"><label>Website<input name="website" placeholder="https://..."></label><label>Company<input name="company"></label><label>Role<input name="role"></label></div><label>Observation<textarea name="observation" rows="3" placeholder="What did you actually notice about their customer journey?"></textarea></label><label>Notes<textarea name="notes" rows="2"></textarea></label><label class="check-row"><input name="research_ready" type="checkbox"> Research complete. Ready for outreach queue.</label><div id="prospect-status"></div><button class="outreach-primary" type="submit">Add Prospect</button></form></section><section class="outreach-card"><h3>Sequence</h3><div class="sequence-list"><p>Initial <strong>Day 0</strong></p>${c.followup_intervals.map((d,i)=>`<p>Follow-up #${i+1}<strong>+${d} days</strong></p>`).join('')}</div></section></div>
    <section class="outreach-card"><div class="outreach-card-head"><h3>Prospects (${prospects.length})</h3><input id="prospect-search" class="small-search" placeholder="Search prospects"></div><div id="prospect-table"></div></section>`);
    root.querySelector('#back-campaigns').onclick=()=>openTab('campaigns');
    root.querySelector('#trash-campaign').onclick=async()=>{if(!confirm('Move this campaign to trash? All outreach from this campaign will be blocked.'))return;try{await api(`/api/admin/outreach/campaigns/${id}`,{method:'DELETE'});await openTab('campaigns');}catch(err){alert(err.message);}};
    root.querySelector('#save-campaign-state').onclick=async()=>{await api(`/api/admin/outreach/campaigns/${id}`,{method:'PATCH',body:JSON.stringify({status:root.querySelector('#campaign-state').value})});campaignDetail(id);};
    const renderProspects=()=>{const q=(root.querySelector('#prospect-search').value||'').toLowerCase();const rows=prospects.filter(p=>[p.name,p.email,p.company,p.status].join(' ').toLowerCase().includes(q));root.querySelector('#prospect-table').innerHTML=rows.length?`<div class="prospect-table">${rows.map(p=>`<button class="prospect-row" data-prospect="${e(p.id)}"><span><strong>${e(p.name||p.email)}</strong><small>${e(p.email)}</small></span><span>${badge(p.email_health)}</span><span>${p.research_ready?'RESEARCH READY':'RESEARCH NEEDED'}</span><span>${badge(p.status)}</span><span>${e(p.initial_due_date)}</span></button>`).join('')}</div>`:`<div class="outreach-empty">No matching prospects.</div>`;root.querySelectorAll('[data-prospect]').forEach(b=>b.onclick=()=>prospectDetail(b.dataset.prospect));};root.querySelector('#prospect-search').oninput=renderProspects;renderProspects();
    let validation=null,timer=null;const emailInput=root.querySelector('#prospect-email'), health=root.querySelector('#email-health');emailInput.addEventListener('input',()=>{clearTimeout(timer);validation=null;health.className='email-health neutral';health.textContent='Checking…';timer=setTimeout(async()=>{try{const r=await api('/api/admin/outreach/validate-email',{method:'POST',body:JSON.stringify({email:emailInput.value})});validation=r.validation;health.className=`email-health ${validation.can_outreach?'good':'bad'}`;health.innerHTML=`<strong>${e(validation.label)}</strong><span>${e(validation.reason)}</span>`;}catch(err){health.className='email-health bad';health.textContent=err.message;}},450);});
    root.querySelector('#prospect-form').onsubmit=async ev=>{ev.preventDefault();const f=new FormData(ev.currentTarget),st=root.querySelector('#prospect-status');try{st.textContent='Saving and validating…';await api('/api/admin/outreach/prospects',{method:'POST',body:JSON.stringify({campaign_id:id,name:f.get('name'),email:f.get('email'),website:f.get('website'),company:f.get('company'),role:f.get('role'),observation:f.get('observation'),notes:f.get('notes'),research_ready:f.get('research_ready')==='on'})});campaignDetail(id);}catch(err){st.className='error-text';st.textContent=err.message;}};
}

async function prospectDetail(id){
    const [d,google,templateData]=await Promise.all([api(`/api/admin/outreach/prospects/${id}`),api('/api/admin/outreach/google/status'),api('/api/admin/outreach/templates')]);
    const p=d.prospect,messages=d.messages||[],events=d.events||[];
    const nextStep=p.last_sent_at===null?0:Number(p.followup_step)+1;
    const template=(templateData.templates||[]).find(t=>Number(t.sequence_step)===nextStep)||{};
    shell(`<div class="detail-top"><button class="text-button" id="back-campaign">← ${e(p.campaign_name)}</button>${badge(p.status)}</div><div class="prospect-hero"><div><span class="outreach-kicker">PROSPECT // ${e(p.sequence_no)}</span><h2>${e(p.name||p.email)}</h2><p>${e(p.email)} · ${e(p.company||'No company')} · ${e(p.role||'No role')}</p></div>${badge(p.email_health)}</div>
    <div class="outreach-grid"><section class="outreach-card"><h3>Prospect Profile</h3><form id="edit-prospect" class="outreach-form compact"><div class="form-row"><label>Name<input name="name" value="${e(p.name)}"></label><label>Website<input name="website" value="${e(p.website)}"></label><label>Company<input name="company" value="${e(p.company)}"></label><label>Role<input name="role" value="${e(p.role)}"></label></div><label>Observation<textarea name="observation" rows="4">${e(p.observation)}</textarea></label><label>Notes<textarea name="notes" rows="3">${e(p.notes)}</textarea></label><label class="check-row"><input name="research_ready" type="checkbox" ${p.research_ready?'checked':''}> Research complete</label><label>Status<select name="status">${['scheduled','contacted','replied','interested','qualified','converted','not_interested','no_response','do_not_contact'].map(s=>`<option ${s===p.status?'selected':''}>${s}</option>`).join('')}</select></label><div class="detail-actions"><button class="outreach-primary" type="submit">Save Prospect</button><button class="outreach-danger" id="trash-prospect" type="button">Move to Trash</button></div></form></section>
    <section class="outreach-card"><h3>Sequence State</h3><div class="sequence-state"><p><span>Initial due</span><strong>${e(p.initial_due_date)}</strong></p><p><span>Last sent</span><strong>${fmt(p.last_sent_at)}</strong></p><p><span>Follow-up step</span><strong>${p.followup_step}/5</strong></p><p><span>Next due</span><strong>${e(p.next_followup_date||'Complete / stopped')}</strong></p></div><div class="email-health ${p.email_health==='mail_ready'?'good':'bad'}"><strong>${e(p.email_health.replaceAll('_',' ').toUpperCase())}</strong><span>${e(p.email_health_reason)}</span></div></section></div>
        <section class="outreach-card"><div class="outreach-card-head"><div><h3>Send Outreach</h3><p class="muted-note">Personalized email from <strong>${e(google.sender||'precious@leakendia.com')}</strong>. Nothing sends until you press the button.</p></div>${google.connected?'<span class="connection-pill">● GMAIL READY</span>':'<span class="outreach-badge paused">GMAIL NOT CONNECTED</span>'}</div><form id="message-form" class="outreach-form"><label>Subject<input name="subject" required value="${e(template.subject||'')}"></label><label>Email presentation<select name="mode" id="outreach-mode"><option value="plain">Personal · Plain text</option><option value="signature">Leakendia Signature · Minimal HTML</option></select></label><label>Email message<textarea name="message" rows="10" required>${e(template.body||'')}</textarea></label><div id="message-status"></div><button class="outreach-primary" type="submit" ${p.sequence_complete||!google.connected?'disabled':''}>${p.sequence_complete?'Sequence Complete':google.connected?'Send Email':'Connect Google Workspace First'}</button></form></section><p class="muted-note">Plain personalized email from <strong>${e(google.sender||'precious@leakendia.com')}</strong>. Nothing sends until you press the button.</p></div>${google.connected?'<span class="connection-pill">● GMAIL READY</span>':'<span class="outreach-badge paused">GMAIL NOT CONNECTED</span>'}</div><form id="message-form" class="outreach-form"><label>Subject<input name="subject" required value="${e(template.subject||'')}"></label><label>Plain email<textarea name="message" rows="10" required>${e(template.body||'')}</textarea></label><div id="message-status"></div><button class="outreach-primary" type="submit" ${p.sequence_complete||!google.connected?'disabled':''}>${p.sequence_complete?'Sequence Complete':google.connected?'Send Email':'Connect Google Workspace First'}</button></form></section>
    <div class="outreach-grid"><section class="outreach-card"><h3>Communication History</h3><div class="history-list">${messages.length?messages.map(x=>`<article><header><strong>${e(x.type.replaceAll('_',' '))} · ${e((x.status||'recorded').toUpperCase())}</strong><time>${fmt(x.sent_at||x.created_at)}</time></header><h4>${e(x.subject)}</h4><pre>${e(x.body)}</pre></article>`).join(''):`<div class="outreach-empty">Nothing recorded yet.</div>`}</div></section><section class="outreach-card"><h3>Activity Timeline</h3><div class="outreach-list">${events.length?events.map(x=>`<div class="activity-row"><div><strong>${e(x.type.replaceAll('_',' '))}</strong><span>${e(x.detail)}</span></div><time>${fmt(x.created_at)}</time></div>`).join(''):`<div class="outreach-empty">No activity yet.</div>`}</div></section></div>`);
    root.querySelector('#back-campaign').onclick=()=>campaignDetail(p.campaign_id);
    root.querySelector('#trash-prospect').onclick=async()=>{if(!confirm('Move this prospect to trash? Future outreach will be blocked.'))return;try{await api(`/api/admin/outreach/prospects/${id}`,{method:'DELETE'});await campaignDetail(p.campaign_id);}catch(err){alert(err.message);}};
    root.querySelector('#edit-prospect').onsubmit=async ev=>{ev.preventDefault();const f=new FormData(ev.currentTarget);await api(`/api/admin/outreach/prospects/${id}`,{method:'PATCH',body:JSON.stringify({name:f.get('name'),website:f.get('website'),company:f.get('company'),role:f.get('role'),observation:f.get('observation'),notes:f.get('notes'),research_ready:f.get('research_ready')==='on',status:f.get('status')})});prospectDetail(id);};
    root.querySelector('#message-form').onsubmit=async ev=>{
        ev.preventDefault();

        const form=ev.currentTarget;
        const f=new FormData(form);
        const st=root.querySelector('#message-status');
        const button=form.querySelector('button[type="submit"]');

        const mode=f.get('mode')==='signature'?'signature':'plain';

        if(!confirm(`Send this ${mode==='signature'?'Leakendia Signature':'plain text'} email now to ${p.email} from ${google.sender||'precious@leakendia.com'}?`))return;

        try{
            button.disabled=true;
            st.className='';
            st.textContent='Sending through Google Workspace…';

            await api('/api/admin/outreach/messages',{
                method:'POST',
                body:JSON.stringify({
                    prospect_id:id,
                    subject:f.get('subject'),
                    message:f.get('message'),
                    mode
                })
            });

            st.className='success-text';
            st.textContent='Sent.';

            await prospectDetail(id);
        }catch(err){
            button.disabled=false;
            st.className='error-text';
            st.textContent=err.message;
        }
    };   {ev.preventDefault();const form=ev.currentTarget,f=new FormData(form),st=root.querySelector('#message-status'),button=form.querySelector('button[type="submit"]');if(!confirm(`Send this email now to ${p.email} from ${google.sender||'precious@leakendia.com'}?`))return;try{button.disabled=true;st.className='';st.textContent='Sending through Google Workspace…';await api('/api/admin/outreach/messages',{method:'POST',body:JSON.stringify({prospect_id:id,subject:f.get('subject'),message:f.get('message')})});st.className='success-text';st.textContent='Sent.';await prospectDetail(id);}catch(err){button.disabled=false;st.className='error-text';st.textContent=err.message;}};
}

async function due(){const d=await api('/api/admin/outreach/due');shell(`<div class="outreach-toolbar"><div><h3>Due Today</h3><p>${e(d.date)} · ${d.prospects.length} actionable prospect${d.prospects.length===1?'':'s'}</p></div></div><div class="queue-list">${d.prospects.length?d.prospects.map((p,i)=>`<button class="queue-card" data-prospect="${e(p.id)}"><span class="queue-number">${String(i+1).padStart(2,'0')}</span><div><strong>${e(p.name||p.email)}</strong><small>${e(p.campaign_name)} · ${e(p.email)}</small></div><span>${p.last_sent_at?`FOLLOW-UP ${Number(p.followup_step)+1}`:'INITIAL'}</span><b>Open →</b></button>`).join(''):`<div class="outreach-empty large">Nothing due. The machine has temporarily stopped demanding emails.</div>`}</div>`);root.querySelectorAll('[data-prospect]').forEach(b=>b.onclick=()=>prospectDetail(b.dataset.prospect));}

async function templates(){const d=await api('/api/admin/outreach/templates');const by=Object.fromEntries((d.templates||[]).map(t=>[t.sequence_step,t]));shell(`<div class="outreach-toolbar"><div><h3>Plain Outreach Templates</h3><p>Templates accelerate writing. Final prospect messages remain editable.</p></div></div><div class="template-grid">${[0,1,2,3,4,5].map(step=>{const t=by[step]||{};return `<form class="outreach-card template-form" data-step="${step}"><h3>${step===0?'Initial Outreach':`Follow-up #${step}`}</h3><label>Name<input name="name" value="${e(t.name||'')}"></label><label>Subject<input name="subject" value="${e(t.subject||'')}"></label><label>Body<textarea name="body" rows="8">${e(t.body||'')}</textarea></label><div class="template-status"></div><button class="outreach-primary">Save Template</button></form>`}).join('')}</div>`);root.querySelectorAll('.template-form').forEach(f=>f.onsubmit=async ev=>{ev.preventDefault();const fd=new FormData(f),s=f.querySelector('.template-status');try{await api('/api/admin/outreach/templates',{method:'POST',body:JSON.stringify({sequence_step:Number(f.dataset.step),name:fd.get('name'),subject:fd.get('subject'),body:fd.get('body')})});s.textContent='Saved.';s.className='template-status success-text';}catch(err){s.textContent=err.message;s.className='template-status error-text';}});}

async function trash(){
    const d=await api('/api/admin/outreach/trash');
    shell(`<div class="outreach-toolbar"><div><span class="outreach-kicker">RECOVERY // ARCHIVE</span><h3>Recycle Bin</h3><p>Restore deleted records. Campaigns return paused; sending never resumes automatically.</p></div></div>
    <section class="outreach-card"><h3>Campaigns (${d.campaigns.length})</h3><div class="outreach-list">${d.campaigns.length?d.campaigns.map(c=>`<div class="activity-row"><div><strong>${e(c.name)}</strong><span>Deleted ${fmt(c.deleted_at)}</span></div><button class="outreach-primary" data-restore-campaign="${e(c.id)}">Restore</button></div>`).join(''):'<p class="outreach-empty">No deleted campaigns.</p>'}</div></section>
    <section class="outreach-card"><h3>Prospects (${d.prospects.length})</h3><div class="outreach-list">${d.prospects.length?d.prospects.map(p=>`<div class="activity-row"><div><strong>${e(p.name||p.email)}</strong><span>${e(p.email)} · ${e(p.campaign_name)} ${p.campaign_deleted_at?'· Restore campaign first':''}</span></div><button class="outreach-primary" data-restore-prospect="${e(p.id)}" ${p.campaign_deleted_at?'disabled':''}>Restore</button></div>`).join(''):'<p class="outreach-empty">No deleted prospects.</p>'}</div></section>`);
    root.querySelectorAll('[data-restore-campaign]').forEach(b=>b.onclick=async()=>{try{await api(`/api/admin/outreach/campaigns/${b.dataset.restoreCampaign}/restore`,{method:'POST'});await trash();}catch(err){alert(err.message);}});
    root.querySelectorAll('[data-restore-prospect]').forEach(b=>b.onclick=async()=>{try{await api(`/api/admin/outreach/prospects/${b.dataset.restoreProspect}/restore`,{method:'POST'});await trash();}catch(err){alert(err.message);}});
}

async function intelligence(){
    const d=await api('/api/admin/outreach/intelligence'), m=d.summary||{};
    const percent=(a,b)=>b?Math.min(100,Math.round(100*Number(a||0)/Number(b))):0;
    const metrics=[['PROSPECTS',m.total],['CONTACTED',m.contacted],['POSITIVE RESPONSES',m.positive],['CONVERTED',m.converted],['POSITIVE RATE',`${m.positive_rate||0}%`],['CONVERSION RATE',`${m.conversion_rate||0}%`]];
    const csvCell=v=>'"'+String(v??'').replaceAll('"','""')+'"';
    shell(`<div class="outreach-toolbar"><div><span class="outreach-kicker">INTELLIGENCE // PIPELINE</span><h3>Acquisition Intelligence</h3><p>Live figures from your outreach records. Positive means replied, interested, qualified or converted.</p></div><button id="intelligence-export" class="outreach-primary">Export Campaign CSV</button></div>
    <div class="outreach-metrics">${metrics.map(([label,value])=>`<article><span>${e(label)}</span><strong>${e(value??0)}</strong></article>`).join('')}</div>
    <section class="outreach-card"><h3>Conversion Journey</h3><div class="sequence-list">${[['Prospects',m.total,m.total],['Contacted',m.contacted,m.total],['Positive responses',m.positive,m.contacted],['Converted',m.converted,m.contacted]].map(([label,n,den])=>`<p><span>${e(label)} <small>(${percent(n,den)}%)</small></span><strong>${e(n||0)}</strong></p>`).join('')}</div><p class="muted-note">Stages represent current status and contact history, not unique email engagement or attributed revenue.</p></section>
    <section class="outreach-card"><h3>Campaign Performance</h3><div class="outreach-list">${d.campaigns.length?d.campaigns.map(c=>`<div class="activity-row"><div><strong>${e(c.name)}</strong><span>${e(c.status)} · ${e(c.prospects||0)} prospects · ${e(c.contacted||0)} contacted · ${e(c.positive||0)} positive</span></div><div><strong>${e(c.converted||0)} won</strong><span>${percent(c.positive,c.contacted)}% positive</span></div></div>`).join(''):'<p class="outreach-empty">No campaign data yet.</p>'}</div></section>
    <section class="outreach-card"><h3>Recent Sending Volume</h3><div class="outreach-list">${d.daily_sends.length?d.daily_sends.map(x=>`<div class="activity-row"><strong>${e(x.day)}</strong><span>${e(x.sent)} sent</span></div>`).join(''):'<p class="outreach-empty">No recorded sends in the last 30 days.</p>'}</div></section>`);
    root.querySelector('#intelligence-export').onclick=()=>{
        const columns=['name','status','prospects','contacted','positive','converted'];
        const csv=[columns.map(csvCell).join(','),...d.campaigns.map(r=>columns.map(k=>csvCell(r[k])).join(','))].join('\r\n');
        const blob=new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8;'}),url=URL.createObjectURL(blob),a=document.createElement('a');
        a.href=url;a.download='leakendia-campaign-intelligence.csv';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
    };
}

async function openTab(tab){currentTab=tab;loading();try{if(tab==='dashboard')await dashboard();else if(tab==='intelligence')await intelligence();else if(tab==='campaigns')await campaignList();else if(tab==='create')await createCampaign();else if(tab==='due')await due();else if(tab==='templates')await templates();else if(tab==='trash')await trash();}catch(err){errorView(err);}}
export function initOutreach(){root=document.getElementById('outreach-root');}
export async function loadOutreach(){if(!root)root=document.getElementById('outreach-root');if(root)await openTab(currentTab);}
